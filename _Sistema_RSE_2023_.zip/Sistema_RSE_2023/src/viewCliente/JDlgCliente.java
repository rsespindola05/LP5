package viewCliente;

import bean.Cliente;
import dao.Cliente_DAO;
import java.text.ParseException;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.text.DefaultFormatterFactory;
import javax.swing.text.MaskFormatter;
import tools.Util;

public class JDlgCliente extends javax.swing.JDialog {
    Cliente_DAO cliente_DAO;
    Cliente cliente;
    boolean incluindo;
    private MaskFormatter mascaraCPF; 
    private MaskFormatter mascaraRG; 
    private MaskFormatter mascaraNumeroDeTelefone;
    
    public JDlgCliente(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        setLocationRelativeTo(null);
        setTitle("Página do Cliente");
        cliente_DAO = new Cliente_DAO();
        Util.habilitar(false, jTxtCodigo, jTxtNome, jFmtRg, jFmtCpf, jTxtIdade, jTxtEndereco, jTxtBairro, jTxtCidade, jTxtEstado, jTxtPais, jTxtComplemento, jTxtEmail, jFmtNumeroDeTelefone, jTxtNomeSocial, jRboMasculino, jRboFeminino , jBtnConfirmar, jBtnCancelar);
        cliente = new Cliente();        
        try{
           mascaraCPF = new MaskFormatter("###.###.###-##");
           mascaraRG = new MaskFormatter( "##.###.###-#" ); 
           mascaraNumeroDeTelefone = new MaskFormatter( "(##)#####-####" ); 
            
        } catch (ParseException ex){
            System.out.println("Erro na mascara");
        }
        jFmtCpf.setFormatterFactory(new DefaultFormatterFactory(mascaraCPF));
        jFmtRg.setFormatterFactory(new DefaultFormatterFactory(mascaraRG));
        jFmtNumeroDeTelefone.setFormatterFactory(new DefaultFormatterFactory(mascaraNumeroDeTelefone));
    
    }
    
    public void beanView(Cliente cliente){
        jTxtCodigo.setText(Util.intStr(cliente.getIdCodigo() ));
        jTxtNome.setText(cliente.getNome());
        jFmtCpf.setText(cliente.getCpf());
        jFmtRg.setText(cliente.getRg());
        jTxtIdade.setText(Util.intStr(cliente.getIdade()));
        jTxtEndereco.setText(cliente.getEndereco());
        jTxtBairro.setText(cliente.getBairro());
        jTxtCidade.setText(cliente.getCidade());
        jTxtEstado.setText(cliente.getEstado());
        jTxtPais.setText(cliente.getPais());
        jTxtComplemento.setText(cliente.getComplemento()); 
        jTxtEmail.setText(cliente.getEmail()); 
        jFmtNumeroDeTelefone.setText(cliente.getNumeroDeTelefone());
        if (cliente.getSexo().equals("M")) {
           jRboMasculino.setSelected(true);
        }
        if (cliente.getSexo().equals("F")) {
           jRboFeminino.setSelected(true);
        }   
        jTxtNomeSocial.setText(cliente.getNomeSocial());
        
    }
    
    public Cliente viewBean(Cliente cliente){
        cliente = new Cliente();
        cliente.setIdCodigo(Util.strInt(jTxtCodigo.getText()));
        cliente.setNome(jTxtNome.getText());
        cliente.setCpf(jFmtCpf.getText());
        cliente.setRg(jFmtRg.getText());
        cliente.setIdade(Util.strInt(jTxtIdade.getText()));
        cliente.setEndereco(jTxtEndereco.getText());
        cliente.setBairro(jTxtBairro.getText());
        cliente.setCidade(jTxtCidade.getText());
        cliente.setEstado(jTxtEstado.getText());
        cliente.setPais(jTxtPais.getText());
        cliente.setComplemento(jTxtComplemento.getText());        
        cliente.setEmail(jTxtEmail.getText());
        cliente.setNumeroDeTelefone(jFmtNumeroDeTelefone.getText());        
        String sexo = "N";
        if (jRboMasculino.isSelected()==true) {
            sexo = "M";
        } 
        if (jRboFeminino.isSelected()==true){
            sexo = "F";
        }
        cliente.setNomeSocial(jTxtNomeSocial.getText());
        /*cliente = new Cliente(Util.strInt(jTxtCodigo.getText()), jTxtNome.getText(), jFmtCpf.getText(), jFmtRg.getText(), 
                Util.strInt(jTxtIdade.getText()), jTxtEndereco.getText(), jTxtBairro.getText(), jTxtCidade.getText(), 
                jTxtEstado.getText(), jTxtPais.getText(), jTxtComplemento.getText(), jTxtEmail.getText(), 
                jFmtNumeroDeTelefone.getText(), sexo, sexo, jTxtNomeSocial.getText());*/
        return cliente;
    }
    
    /*public static void habilitar(boolean valor, JComponent ... componentes) {
        componentes[0].setEnabled(true);
        for (int i = 0; i < componentes.length; i++) {
            componentes[i].setEnabled(valor);            
        }    
    }*/

     public void habilitar(boolean valor) {
        Util.habilitar(valor, jTxtCodigo, jTxtNome, jFmtRg, jFmtCpf, jTxtIdade, jTxtEndereco, jTxtBairro, jTxtCidade, jTxtEstado, jTxtPais, jTxtComplemento, jTxtEmail, jFmtNumeroDeTelefone, jTxtNomeSocial, jRboMasculino, jRboFeminino , jBtnConfirmar, jBtnCancelar);
        Util.habilitar(!valor, jBtnIncluir, jBtnAlterar, jBtnExcluir, jBtnPesquisar);
    }
     
    public void limpar() {
        Util.limpar(jTxtCodigo, jTxtNome, jFmtRg, jFmtCpf, jTxtIdade, jTxtEndereco, jTxtBairro, jTxtCidade, jTxtEstado, jTxtPais, jTxtComplemento, jTxtEmail, jFmtNumeroDeTelefone, jTxtNomeSocial, jRboMasculino, jRboFeminino);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTxtCidade = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jTxtEstado = new javax.swing.JTextField();
        jTxtNome = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        jTxtPais = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jTxtComplemento = new javax.swing.JTextField();
        jFmtCpf = new javax.swing.JFormattedTextField();
        jTxtEmail = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jTxtNomeSocial = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        jRboMasculino = new javax.swing.JRadioButton();
        jRboFeminino = new javax.swing.JRadioButton();
        jFmtNumeroDeTelefone = new javax.swing.JFormattedTextField();
        jLabel8 = new javax.swing.JLabel();
        jFmtRg = new javax.swing.JFormattedTextField();
        jTxtIdade = new javax.swing.JTextField();
        jTxtEndereco = new javax.swing.JTextField();
        jTxtBairro = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jTxtCodigo = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        jBtnIncluir = new javax.swing.JButton();
        jBtnAlterar = new javax.swing.JButton();
        jBtnExcluir = new javax.swing.JButton();
        jBtnConfirmar = new javax.swing.JButton();
        jBtnCancelar = new javax.swing.JButton();
        jBtnPesquisar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel10.setText("Estado");

        jLabel2.setText("Nome");

        jLabel11.setText("País");

        jLabel4.setText("CPF");

        jLabel12.setText("Complemento");

        jLabel5.setText("Idade");

        jLabel6.setText("Endereço");

        jLabel13.setText("Email");

        jLabel7.setText("Bairro");

        jLabel14.setText("Número de telefone");

        jLabel15.setText("Nome Social");

        jLabel16.setText("Sexo");

        jRboMasculino.setText("Masculino");

        jRboFeminino.setText("Feminino");

        jLabel8.setText("RG");

        jLabel9.setText("Cidade");

        jLabel1.setText("Código");

        jPanel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jBtnIncluir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/incluir.png"))); // NOI18N
        jBtnIncluir.setText("Incluir");
        jBtnIncluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnIncluirActionPerformed(evt);
            }
        });
        jPanel1.add(jBtnIncluir);

        jBtnAlterar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/alterar.png"))); // NOI18N
        jBtnAlterar.setText("Alterar");
        jBtnAlterar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnAlterarActionPerformed(evt);
            }
        });
        jPanel1.add(jBtnAlterar);

        jBtnExcluir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Excluir.png"))); // NOI18N
        jBtnExcluir.setText("Excluir");
        jBtnExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnExcluirActionPerformed(evt);
            }
        });
        jPanel1.add(jBtnExcluir);

        jBtnConfirmar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/confirmar.png"))); // NOI18N
        jBtnConfirmar.setText("Confirmar");
        jBtnConfirmar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnConfirmarActionPerformed(evt);
            }
        });
        jPanel1.add(jBtnConfirmar);

        jBtnCancelar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/cancelar.png"))); // NOI18N
        jBtnCancelar.setText("Cancelar");
        jBtnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnCancelarActionPerformed(evt);
            }
        });
        jPanel1.add(jBtnCancelar);

        jBtnPesquisar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/pesquisar.png"))); // NOI18N
        jBtnPesquisar.setText("Pesquisar");
        jBtnPesquisar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnPesquisarActionPerformed(evt);
            }
        });
        jPanel1.add(jBtnPesquisar);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 1003, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addContainerGap()
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel1)
                            .addComponent(jLabel2)
                            .addComponent(jLabel5)
                            .addComponent(jLabel6)
                            .addComponent(jLabel7)
                            .addComponent(jTxtNome, javax.swing.GroupLayout.DEFAULT_SIZE, 250, Short.MAX_VALUE)
                            .addComponent(jTxtCodigo))
                        .addComponent(jLabel4)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jTxtBairro, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTxtEndereco, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTxtIdade, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jFmtRg, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jFmtCpf, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 250, Short.MAX_VALUE))
                        .addComponent(jLabel8))
                    .addGap(161, 161, 161)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel12)
                        .addComponent(jLabel11)
                        .addComponent(jLabel9)
                        .addComponent(jLabel10)
                        .addComponent(jLabel13)
                        .addComponent(jTxtPais, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel15)
                        .addGroup(layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(jFmtNumeroDeTelefone, javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel14)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(jTxtNomeSocial, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 250, Short.MAX_VALUE)
                                        .addComponent(jTxtEmail, javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jTxtComplemento, javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jTxtCidade, javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jTxtEstado))))
                            .addGap(96, 96, 96)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel16)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jRboMasculino)
                                    .addGap(18, 18, 18)
                                    .addComponent(jRboFeminino)))))
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 516, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel1)
                        .addComponent(jLabel9))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jTxtCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jTxtCidade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel2)
                        .addComponent(jLabel10))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jTxtNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jTxtEstado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel4)
                        .addComponent(jLabel11))
                    .addGap(18, 18, 18)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jFmtCpf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(18, 18, 18)
                            .addComponent(jLabel8))
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jTxtPais, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(18, 18, 18)
                            .addComponent(jLabel12)))
                    .addGap(18, 18, 18)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jFmtRg, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(18, 18, 18)
                            .addComponent(jLabel5))
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jTxtComplemento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(18, 18, 18)
                            .addComponent(jLabel13)))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jTxtIdade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(20, 20, 20)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel14)
                                .addComponent(jLabel6))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jTxtEndereco, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jFmtNumeroDeTelefone, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGap(13, 13, 13)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel7)
                                .addComponent(jLabel15)
                                .addComponent(jLabel16)))
                        .addComponent(jTxtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(7, 7, 7)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jTxtBairro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jTxtNomeSocial, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jRboMasculino)
                        .addComponent(jRboFeminino))
                    .addGap(99, 99, 99)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jBtnIncluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnIncluirActionPerformed
        limpar();
        habilitar(true);
        incluindo = true;
    }//GEN-LAST:event_jBtnIncluirActionPerformed

    private void jBtnAlterarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnAlterarActionPerformed
        if ( cliente != null) {
            habilitar(true);
            incluindo = false;
        } else {
            Util.mensagem("Você deve realizar uma pesquisa antes!");
        }        
    }//GEN-LAST:event_jBtnAlterarActionPerformed

    private void jBtnExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnExcluirActionPerformed
        if ( cliente != null) {
        cliente = viewBean(cliente);
        if (Util.perguntar("Deseja excluir o registro?") == true) {
            cliente_DAO.delete(cliente);
            limpar();    
        } else {
            Util.mensagem("Exclusão cancelada!");
        }    
        } else {
        Util.mensagem("Para alterar é necessário fazer uma pesquisa!");
        //jBtnPesquisarActionPerformed(null);
        }
    }//GEN-LAST:event_jBtnExcluirActionPerformed

    private void jBtnConfirmarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnConfirmarActionPerformed
        cliente = viewBean(cliente);
        if(incluindo == true){
            cliente_DAO.insert(cliente);
        } else {
            cliente_DAO.update(cliente);
        }
        cliente = null;
        limpar();
        habilitar(false);
    }//GEN-LAST:event_jBtnConfirmarActionPerformed

    private void jBtnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnCancelarActionPerformed
        limpar();
        habilitar(false);
        cliente = null;
    }//GEN-LAST:event_jBtnCancelarActionPerformed

    private void jBtnPesquisarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnPesquisarActionPerformed
        JDlgClientePesquisar jDlgClientePesquisar = new JDlgClientePesquisar (null, true);
        jDlgClientePesquisar.setTelaAnterior(this);
        jDlgClientePesquisar.setVisible(true);
    }//GEN-LAST:event_jBtnPesquisarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(JDlgCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(JDlgCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(JDlgCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(JDlgCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                JDlgCliente dialog = new JDlgCliente(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jBtnAlterar;
    private javax.swing.JButton jBtnCancelar;
    private javax.swing.JButton jBtnConfirmar;
    private javax.swing.JButton jBtnExcluir;
    private javax.swing.JButton jBtnIncluir;
    private javax.swing.JButton jBtnPesquisar;
    private javax.swing.JFormattedTextField jFmtCpf;
    private javax.swing.JFormattedTextField jFmtNumeroDeTelefone;
    private javax.swing.JFormattedTextField jFmtRg;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JRadioButton jRboFeminino;
    private javax.swing.JRadioButton jRboMasculino;
    private javax.swing.JTextField jTxtBairro;
    private javax.swing.JTextField jTxtCidade;
    private javax.swing.JTextField jTxtCodigo;
    private javax.swing.JTextField jTxtComplemento;
    private javax.swing.JTextField jTxtEmail;
    private javax.swing.JTextField jTxtEndereco;
    private javax.swing.JTextField jTxtEstado;
    private javax.swing.JTextField jTxtIdade;
    private javax.swing.JTextField jTxtNome;
    private javax.swing.JTextField jTxtNomeSocial;
    private javax.swing.JTextField jTxtPais;
    // End of variables declaration//GEN-END:variables
}
