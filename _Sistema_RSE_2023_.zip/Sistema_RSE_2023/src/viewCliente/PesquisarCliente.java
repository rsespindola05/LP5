package viewCliente;

import bean.Cliente;
import java.util.List;
import javax.swing.table.AbstractTableModel;

public class PesquisarCliente extends AbstractTableModel {

    private List lista;
    public void setList(List lista) {
        this.lista = lista;
    }

    public Cliente getCliente(int linha) {
        return (Cliente) lista.get(linha);
    }
    
    @Override
    public int getRowCount() {
        /*if (lista == null){
        return 0;
        } else {*/
         return lista.size();
        //}
    }

    @Override
    public int getColumnCount() {
        return 15;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Cliente cliente = (Cliente) lista.get(rowIndex);
        if (columnIndex == 0) {
            return cliente.getIdCodigo();
        }
        if (columnIndex == 1) {
            return cliente.getNome();
        }
        if (columnIndex == 2) {
            return cliente.getCpf();
        }
        if (columnIndex == 3) {
            return cliente.getRg();
        }
        if (columnIndex == 4) {
            return cliente.getIdade();
        }
        if (columnIndex == 5) {
            return cliente.getEndereco();
        }
        if (columnIndex == 6) {
            return cliente.getBairro();
        }
        if (columnIndex == 7) {
            return cliente.getCidade();
        }
        if (columnIndex == 8) {
            return cliente.getEstado();
        }
        if (columnIndex == 9) {
            return cliente.getPais();
        }
        if (columnIndex == 10) {
            return cliente.getComplemento();
        }
        if (columnIndex == 11) {
            return cliente.getEmail();
        }
        if (columnIndex == 12) {
            return cliente.getNumeroDeTelefone();
        }
        if (columnIndex == 13) {
            return cliente.getSexo();
        }
        if (columnIndex == 14) {
            return cliente.getNomeSocial();
        }
        return null;
    }

    @Override
    public String getColumnName(int column) {
        switch (column) {
            case 0:
                return "id_codigo";
            case 1:
                return "nome";
            case 2:
                return "cpf";
            case 3:
                return "rg";
            case 4:
                return "idade";
            case 5:
                return "endereço";
            case 6:
                return "bairro";
            case 7:
                return "cidade";
            case 8:
                return "estado";
            case 9:
                return "pais";
            case 10:
                return "complemento";
            case 11:
                return "email";
            case 12:
                return "numero_de_telefone";
            case 13:
                return "sexo";
            case 14:
                return "nome_social";
        }
        return null;
    }
}
