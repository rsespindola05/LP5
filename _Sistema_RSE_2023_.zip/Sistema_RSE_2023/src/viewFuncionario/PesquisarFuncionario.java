package viewFuncionario;

import bean.Funcionario;
import java.util.List;
import javax.swing.table.AbstractTableModel;

public class PesquisarFuncionario extends AbstractTableModel {

    private List lista;
    public void setList(List lista) {
        this.lista = lista;
    }
    
    public Funcionario getFuncionario(int linha) {
        return (Funcionario) lista.get(linha);
    }

    @Override
    public int getRowCount() {
        /*if (lista == null){
        return 0;
        } else {*/
        return lista.size();
        //}
    }

    @Override
    public int getColumnCount() {
        return 5;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Funcionario funcionario = (Funcionario) lista.get(rowIndex);
        if (columnIndex == 0) {
            return funcionario.getIdCodigo();
        }
        if (columnIndex == 1) {
            return funcionario.getNome();
        }
        if (columnIndex == 2) {
            return funcionario.getFuncao();
        }
        if (columnIndex == 3) {
            return funcionario.getCpf();
        }
        if (columnIndex == 4) {
            return funcionario.getEmail();
        }
        return null;
    }

    @Override
    public String getColumnName(int column) {
        switch (column) {
            case 0:
                return "id_codigo";
            case 1:
                return "nome";
            case 2:
                return "funcao";
            case 3:
                return "cpf";
            case 4:
                return "email";
        }
        return null;
    }
}
