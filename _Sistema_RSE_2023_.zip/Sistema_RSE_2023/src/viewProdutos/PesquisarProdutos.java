package viewProdutos;

import bean.Produtos;
import java.util.List;
import javax.swing.table.AbstractTableModel;

public class PesquisarProdutos extends AbstractTableModel {

    private List lista;
    public void setList(List lista) {
        this.lista = lista;
    }
    
    public Produtos getProdutos(int linha) {
        return (Produtos) lista.get(linha);
    }

    @Override
    public int getRowCount() {
        /*if (lista == null){
        return 0;
        } else {*/
            return lista.size();
        //}
    }

    @Override
    public int getColumnCount() {
        return 5;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Produtos produtos = (Produtos) lista.get(rowIndex);
        if (columnIndex == 0) {
            return produtos.getIdCodigo();
        }
        if (columnIndex == 1) {
            return produtos.getNome();
        }
        if (columnIndex == 2) {
            return produtos.getPreco();
        }
        if (columnIndex == 3) {
            return produtos.getQuantidade();
        }
        if (columnIndex == 4) {
            return produtos.getMarca();
        }   
        return null;
    }

    @Override
    public String getColumnName(int column) {
        /*passa a variavel*/
        switch (column) {
            case 0:
                return "id_codigo";
            case 1:
                return "nome";
            case 2:
                return "preco";
            case 3:
                return "quantidade";
            case 4:
                return "marca";
        }
        return null;
    }
}
