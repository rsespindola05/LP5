package viewUsuarios;

import bean.Usuarios;
import java.util.List;
import javax.swing.table.AbstractTableModel;

public class PesquisarUsuarios extends AbstractTableModel {

    private List lista;
    public void setList(List lista) {
        this.lista = lista;
    }
    
    public Usuarios getUsuarios(int linha) {
        return (Usuarios) lista.get(linha);
    }

    @Override
    public int getRowCount() {
        /*if (lista == null){
            return 0;
        } else {*/
            return lista.size();
        //}
    }

    @Override
    public int getColumnCount() {
        return 8;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Usuarios usuarios = (Usuarios) lista.get(rowIndex);
        if (columnIndex == 0) {
            return usuarios.getIdUsuarios();
        }
        if (columnIndex == 1) {
            return usuarios.getNome();
        }
        if (columnIndex == 2) {
            return usuarios.getApelido();
        }
        if (columnIndex == 3) {
            return usuarios.getDataNascimento();
        }
        if (columnIndex == 4) {
            return usuarios.getCpf();
        }
        if (columnIndex == 5) {
            return usuarios.getSenha();
        }
        if (columnIndex == 6) {
            return usuarios.getNivel();
        }
        if (columnIndex == 7) {
            return usuarios.getAtivo();
        }
        return null;
    }
   
    @Override
    public String getColumnName(int column) {
        switch (column) {
            case 0:
                return "id_usuarios";
            case 1:
                return "nome";
            case 2:
                return "apelido";
            case 3:
                return "dataNascimento";
            case 4:
                return "cpf";
            case 5:
                return "senha";
            case 6:
                return "nivel";
            case 7:
                return "ativo";    
        }
        return null;
    }
}