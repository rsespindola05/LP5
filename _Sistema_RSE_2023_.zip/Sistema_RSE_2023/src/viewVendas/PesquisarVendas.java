package viewVendas;

import bean.Vendas;
import java.util.List;
import javax.swing.table.AbstractTableModel;

public class PesquisarVendas extends AbstractTableModel {
    
    private List lista;    
    public void setList(List lista) {
        this.lista = lista;   
    }
    
    public Vendas getVendas(int linha) {
        return (Vendas) lista.get(linha);
    }
   
    @Override
    public int getRowCount() {
        /*if (lista == null){
            return 0;
        } else {*/
            return lista.size();
        //}
    }

    @Override
    public int getColumnCount() {
       return 5;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Vendas vendas = (Vendas) lista.get(rowIndex);
        if (columnIndex == 0) {
            return vendas.getIdCodigo();
        }
        if (columnIndex == 1) {
            return vendas.getData();
        }
        if (columnIndex == 2) {
            return vendas.getCliente();
        }
        if (columnIndex == 3) {
            return vendas.getFuncionario();
        }
        if (columnIndex == 4) {
            return vendas.getTotal();
        }
        return null;
    }
   
    @Override
    public String getColumnName(int column) {
        switch (column) {
            case 0: return "id_codigo";
            case 1: return "data";
            case 2: return "fk_cliente";
            case 3: return "fk_funcionario";
            case 4: return "total";
        }
        return null;
    }
}
