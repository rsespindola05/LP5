package viewCliente;

import java.util.List;
import javax.swing.table.AbstractTableModel;

public class PesquisarCliente extends AbstractTableModel {

    private List lista;
    public void setList(List lista) {
        this.lista = lista;
    }

    @Override
    public int getRowCount() {
        if (lista == null){
        return 0;
        } else {
         return lista.size();
        }
    }

    @Override
    public int getColumnCount() {
        return 15;
    }

    @Override
    public Object getValueAt(int row, int column) {
        return null;
    }

    @Override
    public String getColumnName(int column) {
        /*passa a variavel*/
        switch (column) {
            case 0:
                return "id_codigo";
            case 1:
                return "nome";
            case 2:
                return "cpf";
            case 3:
                return "rg";
            case 4:
                return "idade";
            case 5:
                return "endereço";
            case 6:
                return "bairro";
            case 7:
                return "cidade";
            case 8:
                return "estado";
            case 9:
                return "pais";
            case 10:
                return "complemento";
            case 11:
                return "email";
            case 12:
                return "numero_de_telefone";
            case 13:
                return "sexo";
            case 14:
                return "nome_social";
        }
        return null;
    }
}
