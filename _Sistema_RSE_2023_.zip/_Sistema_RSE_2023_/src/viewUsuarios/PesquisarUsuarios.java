package viewUsuarios;

import java.util.List;
import javax.swing.table.AbstractTableModel;

public class PesquisarUsuarios extends AbstractTableModel {

    private List lista;
    public void setList(List lista) {
        this.lista = lista;
    }

    @Override
    public int getRowCount() {
        if (lista == null){
        return 0;
        } else {
         return lista.size();
        }
    }

    @Override
    public int getColumnCount() {
        return 8;
    }

    @Override
    public Object getValueAt(int row, int column) {
        return null;
    }

    @Override
    public String getColumnName(int column) {
        /*passa a variavel*/
        switch (column) {
            case 0:
                return "id_usuarios";
            case 1:
                return "nome";
            case 2:
                return "apelido";
            case 3:
                return "dataNascimento";
            case 4:
                return "cpf";
            case 5:
                return "senha";
            case 6:
                return "nivel";
            case 7:
                return "ativo";    
        }
        return null;
    }
}
